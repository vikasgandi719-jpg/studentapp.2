import { createBrowserRouter } from "react-router";
import { LandingPage } from "./components/LandingPage";
import { AdminLoginPage } from "./components/AdminLoginPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/admin-login",
    Component: AdminLoginPage,
  },
]);
