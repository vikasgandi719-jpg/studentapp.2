import { useNavigate } from 'react-router';
import { AdminLogin } from './AdminLogin';
import { Toaster } from './ui/sonner';

export function AdminLoginPage() {
  const navigate = useNavigate();

  return (
    <>
      <div className="min-h-screen w-full flex items-center justify-center bg-neutral-50 p-4">
        <AdminLogin onBack={() => navigate('/')} />
      </div>
      <Toaster position="top-center" />
    </>
  );
}
