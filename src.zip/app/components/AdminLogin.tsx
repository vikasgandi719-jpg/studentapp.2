import { useState } from 'react';
import { Mail, Phone, Lock, ArrowRight, Shield, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';
import { toast } from 'sonner';

export function AdminLogin({ onBack }: { onBack?: () => void }) {
  const [authMethod, setAuthMethod] = useState<'password' | 'otp'>('password');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendOTP = async () => {
    if (!email && !phone) {
      toast.error('Please enter email or phone number');
      return;
    }

    setIsLoading(true);
    // Mock OTP generation
    setTimeout(() => {
      setOtpSent(true);
      setIsLoading(false);
      toast.success('OTP sent successfully! (Mock: 123456)');
    }, 1000);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email && !phone) {
      toast.error('Please enter email or phone number');
      return;
    }

    if (authMethod === 'password' && !password) {
      toast.error('Please enter your password');
      return;
    }

    if (authMethod === 'otp' && otp.length !== 6) {
      toast.error('Please enter valid 6-digit OTP');
      return;
    }

    setIsLoading(true);
    // Mock login
    setTimeout(() => {
      setIsLoading(false);
      toast.success('Login successful! Welcome, Admin');
    }, 1500);
  };

  return (
    <div className="w-full max-w-md p-8 bg-white rounded-2xl shadow-sm border border-neutral-200">
      {/* Back Button */}
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-neutral-600 hover:text-neutral-900 mb-6 transition-colors group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Back to Home
        </button>
      )}

      {/* Header */}
      <div className="flex flex-col items-center mb-8">
        <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center mb-4 shadow-md">
          <Shield className="w-7 h-7 text-white" />
        </div>
        <h1 className="text-2xl font-semibold text-neutral-900 mb-1">Admin Portal</h1>
        <p className="text-sm text-neutral-600">Document Management System</p>
      </div>

      <form onSubmit={handleLogin} className="space-y-5">
        {/* Contact Information */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email Address
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="admin@institution.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-11 bg-neutral-50 border-neutral-300 focus:bg-white"
            />
          </div>

          <div>
            <Label htmlFor="phone" className="text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Phone Number
            </Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+1 (555) 000-0000"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="h-11 bg-neutral-50 border-neutral-300 focus:bg-white"
            />
          </div>
        </div>

        {/* Authentication Method Tabs */}
        <Tabs value={authMethod} onValueChange={(value) => setAuthMethod(value as 'password' | 'otp')} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-neutral-100">
            <TabsTrigger value="password" className="text-sm">Password</TabsTrigger>
            <TabsTrigger value="otp" className="text-sm">OTP</TabsTrigger>
          </TabsList>

          <TabsContent value="password" className="mt-4 space-y-4">
            <div>
              <Label htmlFor="password" className="text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-2">
                <Lock className="w-4 h-4" />
                Password
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11 bg-neutral-50 border-neutral-300 focus:bg-white"
              />
            </div>
            <button
              type="button"
              className="text-sm text-blue-600 hover:text-blue-700 font-medium transition-colors"
            >
              Forgot password?
            </button>
          </TabsContent>

          <TabsContent value="otp" className="mt-4 space-y-4">
            {!otpSent ? (
              <div className="text-center py-4">
                <p className="text-sm text-neutral-600 mb-4">
                  We'll send a 6-digit verification code to your email or phone
                </p>
                <Button
                  type="button"
                  onClick={handleSendOTP}
                  disabled={isLoading}
                  variant="outline"
                  className="w-full h-11"
                >
                  {isLoading ? 'Sending...' : 'Send OTP'}
                </Button>
              </div>
            ) : (
              <div>
                <Label className="text-sm font-medium text-neutral-700 mb-2 block">
                  Enter 6-digit OTP
                </Label>
                <div className="flex justify-center mb-4">
                  <InputOTP
                    maxLength={6}
                    value={otp}
                    onChange={(value) => setOtp(value)}
                  >
                    <InputOTPGroup>
                      <InputOTPSlot index={0} className="w-11 h-11" />
                      <InputOTPSlot index={1} className="w-11 h-11" />
                      <InputOTPSlot index={2} className="w-11 h-11" />
                      <InputOTPSlot index={3} className="w-11 h-11" />
                      <InputOTPSlot index={4} className="w-11 h-11" />
                      <InputOTPSlot index={5} className="w-11 h-11" />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setOtpSent(false);
                    setOtp('');
                  }}
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium transition-colors"
                >
                  Resend OTP
                </button>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Login Button */}
        <Button
          type="submit"
          disabled={isLoading}
          className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-medium text-base shadow-sm"
        >
          {isLoading ? (
            'Authenticating...'
          ) : (
            <span className="flex items-center justify-center gap-2">
              Sign In
              <ArrowRight className="w-5 h-5" />
            </span>
          )}
        </Button>
      </form>

      {/* Footer */}
      <div className="mt-6 pt-6 border-t border-neutral-200">
        <p className="text-xs text-center text-neutral-500">
          Secured access for authorized administrators only
        </p>
      </div>
    </div>
  );
}