import { useNavigate } from 'react-router';
import { Shield, FileText, Upload, Users, Lock, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';

export function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen w-full bg-neutral-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Main Card */}
        <div className="bg-white rounded-3xl shadow-sm border border-neutral-200 overflow-hidden">
          {/* Header Section */}
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 px-8 py-12 text-center">
            <div className="inline-flex w-20 h-20 bg-white/10 backdrop-blur-sm rounded-2xl items-center justify-center mb-6 shadow-lg">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-semibold text-white mb-3">
              Document Management System
            </h1>
            <p className="text-blue-100 text-lg max-w-2xl mx-auto">
              Secure platform for accessing and managing educational documentation
            </p>
          </div>

          {/* Content Section */}
          <div className="px-8 py-10">
            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-neutral-50">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-medium text-neutral-900 mb-2">Access Documents</h3>
                <p className="text-sm text-neutral-600">
                  View and download educational materials securely
                </p>
              </div>

              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-neutral-50">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Upload className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-medium text-neutral-900 mb-2">Upload Files</h3>
                <p className="text-sm text-neutral-600">
                  Share and organize institutional documents
                </p>
              </div>

              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-neutral-50">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-medium text-neutral-900 mb-2">Manage Access</h3>
                <p className="text-sm text-neutral-600">
                  Control permissions and user access levels
                </p>
              </div>
            </div>

            {/* Admin Access Section */}
            <div className="bg-gradient-to-r from-neutral-50 to-blue-50 rounded-2xl p-8 border border-neutral-200">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-blue-600 rounded-xl flex items-center justify-center shadow-md flex-shrink-0">
                    <Lock className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-neutral-900 mb-1">
                      Administrator Access
                    </h2>
                    <p className="text-sm text-neutral-600">
                      Sign in to manage documents and system settings
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => navigate('/admin-login')}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium h-12 px-8 shadow-sm flex-shrink-0"
                >
                  <span className="flex items-center gap-2">
                    Admin Login
                    <ArrowRight className="w-5 h-5" />
                  </span>
                </Button>
              </div>
            </div>

            {/* Footer Info */}
            <div className="mt-8 text-center">
              <p className="text-xs text-neutral-500">
                Authorized access only • Secure authentication required
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Text */}
        <p className="text-center text-sm text-neutral-500 mt-6">
          © 2026 Educational Institution • All rights reserved
        </p>
      </div>
    </div>
  );
}
